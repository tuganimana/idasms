# idasms 

Idasms is a python packages which allow you to send  bulk sms . 

before installing this packages you need to get intouch with Ida technology to provide  credentials of bulk sms to their bulks sms API.
after that  you ready to go
